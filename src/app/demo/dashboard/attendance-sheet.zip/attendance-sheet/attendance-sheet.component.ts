// Updated attendance-sheet.component.ts with Chart.js integration
import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { Chart, ChartConfiguration, ChartType, registerables } from 'chart.js';
import { CommonModule } from '@angular/common';

Chart.register(...registerables);

interface AttendanceRecord {
  date: number;
  day: string;
  shift: number;
  dayStatus: 'PP' | 'AA' | 'IP' | 'PA';
  checkIn: string;
  checkOut: string;
  breakTime: string;
  workingHours: string;
  extraHours: string;
  lateTime: string;
  earlyTime: string;
}

@Component({
  selector: 'app-attendance-sheet',
  templateUrl: './attendance-sheet.component.html',
  styleUrls: ['./attendance-sheet.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class AttendanceSheetComponent implements OnInit, AfterViewInit, OnDestroy {
  
  @ViewChild('attendanceChart', { static: false }) chartRef!: ElementRef<HTMLCanvasElement>;
  private chart: Chart | null = null;
  
  // Configuration
  currentDepartment = 'Administration';
  currentYear = 2025;
  currentMonth = 'August';
  
  // Statistics
  attendanceRatio = 93;
  dailyAttendanceData: number[] = [];
  
  // Summary data
  summary = {
    fullDays: 10,
    halfDays: 1,
    presentDays: 10,
    absentDays: 1,
    leaves: 0,
    lateDays: 10,
    holidays: 0,
    earlyDays: 10,
    totalLateEarlyPenalty: 0,
    appliedPenalty: 0,
    extraHours: 0,
    totalWorkHours: 0
  };
  
  // Employee data
  employees = [
    {
      name: 'Mrs. Pasang Lhamo',
      designation: 'ADM',
      records: [] as AttendanceRecord[]
    }
  ];
  
  // Calendar data
  daysInMonth = 31;
  public weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  // --- Attendance Summary Table Data ---
  public days = Array.from({ length: 31 }, (_, i) => i + 1);

  public get weekHeaders() {
    return this.days.map((d, i) => this.weekDays[i % 7]);
  }

  public employee = {
    name: 'Mrs. Pasang Lhamo',
    designation: 'ADM'
  };

  public data = {
    shift: Array(31).fill(1),
    status: [
      'AA', 'PP', 'PP', 'PP', 'AA', 'PP', 'PP',
      'PP', 'PP', 'PP', 'PP', 'PP', 'PA', 'PP',
      'PP', 'PP', 'PP', 'PP', 'PP', 'PP', 'PP',
      'AA', 'PP', 'PP', 'PP', 'PP', 'PP', 'PP',
      'PP', 'AA', 'PP'
    ],
    checkIn: Array(31).fill('8:30'),
    checkOut: Array(31).fill('17:00'),
    breakTime: Array(31).fill('0:00'),
    workingHours: Array(31).fill('8:30'),
    extraHours: Array(31).fill('0:00'),
    lateTime: Array(31).fill('0:00'),
    earlyTime: Array(31).fill('0:00')
  };

  public totals = {
    fullDay: 10,
    halfDay: 1,
    presentDay: 10,
    absentDay: 1,
    leaves: 0,
    lateDays: 0,
    holidays: 0,
    earlyDays: 10,
    latePenalty: 0,
    penalty: 0,
    extraHours: 0,
    totalWorkHours: 0
  };

  public repeatTimes = 2; // to duplicate the block twice
  
  ngOnInit() {
    this.generateDailyAttendanceData();
    this.generateEmployeeRecords();
  }
  
  ngAfterViewInit() {
    this.initChart();
  }
  
  initChart() {
    if (this.chart) {
      this.chart.destroy();
    }
    const ctx = this.chartRef.nativeElement.getContext('2d');
    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: Array.from({ length: this.daysInMonth }, (_, i) => i + 1), // 1,2,3,...31
        datasets: [{
          label: 'Daily Attendance',
          data: this.dailyAttendanceData,
          backgroundColor: 'rgba(121, 134, 203, 0.8)',
          borderColor: 'rgba(121, 134, 203, 1)',
          borderWidth: 1,
          borderRadius: 4,
          maxBarThickness: 20
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: 0 },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (context) => `Attendance: ${context.parsed.y}`,
              title: (context) => `Day ${context[0].label}`
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 10,
            ticks: {
              stepSize: 2,
              font: {
                size: 11
              }
            },
            grid: {
              display: true,
              // @ts-ignore
              borderDash: [8, 4],
              color: 'rgba(0,0,0,0.15)'
            }
          },
          x: {
            ticks: {
              font: {
                size: 10,
                style: 'normal'
              },
              autoSkip: false // Show all days
            },
            grid: {
              display: false // Hide vertical grid lines
            }
          }
        }
      }
    });
  }
  
  
  generateDailyAttendanceData() {
    // Generate sample data for the chart (attendance count per day)
    for (let i = 1; i <= this.daysInMonth; i++) {
      // Simulate varying attendance (7-10 people)
      const baseAttendance = 8;
      const variation = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
      this.dailyAttendanceData.push(Math.max(6, Math.min(10, baseAttendance + variation)));
    }
  }
  
  generateEmployeeRecords() {
    const employee = this.employees[0];
    
    for (let day = 1; day <= this.daysInMonth; day++) {
      const dayOfWeek = this.getDayOfWeek(day);
      let dayStatus: 'PP' | 'AA' | 'IP' | 'PA' = 'PP';
      
      // Set some days as absent or irregular based on image
      if (day === 4 || day === 5 || day === 28 || day === 31) {
        dayStatus = 'AA';
      } else if (day === 11) {
        dayStatus = 'IP';
      } else if (day === 16) {
        dayStatus = 'PA';
      }
      
      const record: AttendanceRecord = {
        date: day,
        day: dayOfWeek,
        shift: 1,
        dayStatus: dayStatus,
        checkIn: dayStatus === 'AA' ? '' : '8:30',
        checkOut: dayStatus === 'AA' ? '' : (dayStatus === 'PA' ? '12:00' : '17:00'),
        breakTime: '0:00',
        workingHours: dayStatus === 'AA' ? '' : (dayStatus === 'PA' ? '3:30' : '8:30'),
        extraHours: '0:00',
        lateTime: '0:00',
        earlyTime: '0:00'
      };
      
      employee.records.push(record);
    }
  }
  
  getDayOfWeek(day: number): string {
    // August 2025 starts on Friday (index 4)
    const startDay = 4; // Friday = 4 (0=Sunday, 1=Monday, etc.)
    const dayIndex = (startDay + day - 1) % 7;
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return days[dayIndex];
  }
  
  getStatusClass(status: string): string {
    switch (status) {
      case 'AA': return 'status-absent';
      case 'IP': return 'status-irregular';
      case 'PA': return 'status-half-day';
      default: return 'status-present';
    }
  }
  
  getCheckInClass(record: AttendanceRecord): string {
    if (record.dayStatus === 'AA') return 'status-absent';
    if (record.dayStatus === 'IP') return 'status-irregular';
    if (record.dayStatus === 'PA') return 'status-half-day';
    return 'status-present';
  }
  
  getCheckOutClass(record: AttendanceRecord): string {
    if (record.dayStatus === 'AA') return 'status-absent';
    if (record.dayStatus === 'IP') return 'status-irregular';
    if (record.dayStatus === 'PA') return 'status-half-day';
    return 'status-present';
  }
  
  getWorkingHoursClass(record: AttendanceRecord): string {
    if (record.dayStatus === 'AA') return 'status-absent';
    if (record.dayStatus === 'IP') return 'status-irregular';
    if (record.dayStatus === 'PA') return 'status-half-day';
    return 'status-present';
  }
  
  getDaysArray(): number[] {
    return Array.from({ length: this.daysInMonth }, (_, i) => i + 1);
  }
  
  getCalendarHeaders(): string[] {
    const headers: string[] = [];
    for (let day = 1; day <= this.daysInMonth; day++) {
      const dayOfWeek = this.getDayOfWeek(day);
      headers.push(dayOfWeek);
    }
    return headers;
  }
  
  // Additional methods for enhanced functionality
  exportToExcel() {
    // Implementation for Excel export
    console.log('Exporting to Excel...');
  }
  
  exportToPDF() {
    // Implementation for PDF export
    console.log('Exporting to PDF...');
  }
  
  printReport() {
    window.print();
  }
  
  ngOnDestroy() {
    if (this.chart) {
      this.chart.destroy();
    }
  }
}