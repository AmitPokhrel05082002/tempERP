// Tashi Tshering

import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormArray, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { catchError, throwError, tap, of, map, Observable, concatMap, from, EMPTY, take, timeout, finalize } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, Permission } from 'src/app/core/services/auth.service';



// =============================================
// INTERFACE DEFINITIONS
// =============================================
interface UserAccount {
  userId: string;
  empId: string;
  username: string;
  email: string;
  roleId: string;
  accountStatus: string;
  mustChangePassword: boolean;
  passwordChangedDate: string;
  lastLoginDate: string;
  failedLoginAttempts: number;
  accountLockedUntil: string;
  createdDate: string;
  modifiedDate: string;
  isDeptHead: boolean;
  deptId: string;
  isAccountLocked: boolean;
}
/**
 * Core employee data structures
 */
interface Department {
  dept_id: string;
  dept_name: string;
  dept_code: string;
  org_name: string;
  branch_name: string;
  budget_allocation: number;
  sub_departments_count: number;
}

interface Position {
  positionId: string;
  positionName: string;
  positionCode: string;
  deptName: string;
}

interface Grade {
  gradeId: string;
  gradeName: string;
  gradeCode: string;
  minSalary: number;
  maxSalary: number;
}

interface SalaryStructure {
  gradeId: string;
  gradeName: string;
  minSalary: number;
  maxSalary: number;
  salaryStructures: any[];
}

interface Branch {
  branchId: string;
  branchName: string;
  branchCode: string;
  dzongkhag: string;
  thromde: string;
  operationalStatus: boolean;
  organizationName: string;
}

/**
 * Employee sub-structures
 */
interface Address {
  addressId?: string;
  addressType: 'Permanent' | 'Temporary' | 'Correspondence';
  addressLine1: string;
  addressLine2: string;
  thromde: string;
  dzongkhag: string;
  country: string;
  isCurrent: boolean;
}

interface BankDetail {
  bankDetailId?: string;
  bankName: string;
  branchName: string;
  accountNumber: string;
  accountType: string;
}

interface Qualification {
  qualificationId?: string;
  institutionName: string;
  degreeName: string;
  specialization: string;
  yearOfCompletion: number;
}

interface Contact {
  contactId?: string;
  contactType: 'Email';
  email: string;
  phonePrimary: string;
  isEmergencyContact: boolean;
}

/**
 * Main Employee interface
 */
interface Employee {
  profileImage?: string;
  empId: string;
  empCode: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  maritalStatus: string;
  nationality: string;
  cidNumber: string;
  hireDate: string;
  employmentStatus: string;
  employmentType: 'Regular' | 'Contract' | 'Temporary' | 'Probation' | 'Intern' | 'Consultant';
  email: string;
  deptId?: string;
  department: string;
  location: string;
  positionId?: string;
  positionName?: string;
  shiftId?: string;
  gradeId?: string;
  basicSalary?: number;
  maxSalary?: number;
  qualifications: Qualification[];
  bankDetails: BankDetail[];
  addresses: Address[];
  contacts: Contact[];
  orgId?: string;
  branchId?: string;
  createdDate?: string;
  modifiedDate?: string;
}

interface ApiEmployeeResponse {
  employee: {
    empId: string;
    orgId: string;
    branchId: string;
    deptId: string;
    gradeId: string;
    positionId: string;
    shiftId: string;
    empCode: string;
    firstName: string;
    middleName: string | null;
    lastName: string;
    dateOfBirth: string;
    gender: string;
    maritalStatus: string | null;
    bloodGroup: string;
    nationality: string;
    socialSecurityNumber: string;
    cidNumber: string;
    hireDate: string;
    employmentStatus: string;
    employmentType: 'Regular' | 'Contract' | 'Temporary' | 'Probation' | 'Intern' | 'Consultant';
    basicSalary: number;
    maxSalary: number;
    createdDate: string;
    modifiedDate: string;
  };
  contacts: any[];
  addresses: any[];
  qualifications: any[];
  bankDetails: any[];
  history: any[];
}
interface Shift {
  shiftId: string;
  orgId: string;
  shiftName: string;
  shiftCode: string;
  startTime: string;
  endTime: string;
  breakDurationMinutes: number;
  totalWorkHours: number;
  isNightShift: boolean;
  isActive: boolean;
  createdDate: string;
  modifiedDate: string;
}

// =============================================
// COMPONENT DEFINITION
// =============================================

@Component({
  selector: 'app-emp-det',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, DatePipe],
  templateUrl: './emp-det.component.html',
  styleUrls: ['./emp-det.component.scss']
})
export class EmployeeDetailComponent implements OnInit {
  // =============================================
  // COMPONENT STATE
  // =============================================

  // Form Management
  employeeForm: FormGroup;
  isEditMode = false;
  editedIndex = -1;
  selectedEmployee: Employee | null = null;
  selectedBranchId: string = '';
  // UI State
  showModal = false;
  showViewModal = false;
  modalActiveTab: string = 'basic';
  activeTab = 'All Employee';
  activeViewTab: string = '';
  searchQuery = '';
  isLoading = false;
  isSaving = false;
  errorMessage = '';

  // Data Collections
  employees: Employee[] = [];
  filteredEmployees: Employee[] = [];
  grades: Grade[] = [];
  selectedGrade: Grade | null = null;
  salaryStructure: SalaryStructure | null = null;
  tabDepartments: (Department | string)[] = ['All Employee'];
  filteredDepartments: Department[] = [];
  formDepartments: Department[] = [];
  positions: Position[] = [];
  filteredPositions: Position[] = [];
  branches: Branch[] = [];
  locations: string[] = [];
  organizations: any[] = [];
  selectedOrgId: string = '';

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalItems = 0;
  pageSizeOptions = [5, 10, 25, 50];
  Math = Math;
  shifts: Shift[] = [];
  selectedShiftId: string = '';

  // create-user-pop-up
 showUserCreationModal = false;
isCreatingUser = false;
newEmployeeId: string | null = null;
newEmployeeCode: string = '';
newEmployeeDetails: any = null;

  // API Configuration
  private readonly apiUrl = `${environment.apiUrl}/api/v1/employees`;
  private readonly deptApiUrl = `${environment.apiUrl}/api/v1/departments`;
  private readonly positionApiUrl = `${environment.apiUrl}/api/v1/job-positions`;
  private readonly branchApiUrl = `${environment.apiUrl}/api/v1/branches`;
  private readonly gradeApiUrl = `${environment.apiUrl}/api/v1/job-grades`;
  private readonly orgApiUrl = `${environment.apiUrl}/api/v1/organizations`;
  private readonly documentUploadUrl = `${environment.apiUrl}/api/archive/upload`;
  private readonly shiftApiUrl = `${environment.apiUrl}/api/v1/shifts`;
  private readonly httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  // Mapping dictionaries
  private departmentMap: { [key: string]: string } = {};
  private positionMap: { [key: string]: string } = {};
  private locationMap: { [key: string]: string } = {};

  // =============================================
  // COMPONENT INITIALIZATION
  // =============================================

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    this.route.snapshot.paramMap.get('empCode');
    this.loadInitialData();
  }

  private initializeForm(): void {
    this.employeeForm = this.fb.group({
      // Personal Information
      firstName: ['', [Validators.required, Validators.maxLength(50)]],
      middleName: [''],
      lastName: ['', [Validators.required, Validators.maxLength(50)]],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      maritalStatus: ['', Validators.required],
      nationality: ['Bhutanese', Validators.required],
      cidNumber: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],
      organization: ['', Validators.required],

      // Employment Information
      hireDate: ['', Validators.required],
      employmentStatus: ['', Validators.required],
      employmentType: ['', Validators.required],
      department: ['', Validators.required],
      position: [null, Validators.required],
      location: ['', Validators.required],
      grade: ['', Validators.required],
      basicSalary: ['', Validators.required],
      maxSalary: ['', Validators.required],

      // Contact Information
      email: ['', [Validators.required, Validators.email]],
      phonePrimary: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],

      // Bank Details
      bankName: [''],
      branchName: [''],
      accountNumber: [''],
      accountType: [''],

      // Education
      institutionName: [''],
      degreeName: [''],
      specialization: [''],
      yearOfCompletion: [0],
      educations: this.fb.array([]),
      // Address
      addressType: ['Permanent'],
      addressLine1: [''],
      addressLine2: [''],
      thromde: [''],
      dzongkhag: [''],
      country: ['Bhutan'],

      //shift
      shift: ['', Validators.required],
    });
    this.onNationalityChange();

  }
 get educations(): FormArray {
  return this.employeeForm.get('educations') as FormArray;
}
 addEducation(education?: Qualification): void {
  this.educations.push(this.createEducationFormGroup(education));
}

  // Check if main education form has values
  private hasMainEducationValues(): boolean {
    return !!this.employeeForm.get('institutionName')?.value ||
      !!this.employeeForm.get('degreeName')?.value ||
      !!this.employeeForm.get('specialization')?.value ||
      !!this.employeeForm.get('yearOfCompletion')?.value;
  }

  // Save main education to the educations array
  private saveMainEducationToArray(): void {
    const mainEducation: Qualification = {
      institutionName: this.employeeForm.get('institutionName')?.value,
      degreeName: this.employeeForm.get('degreeName')?.value,
      specialization: this.employeeForm.get('specialization')?.value,
      yearOfCompletion: this.employeeForm.get('yearOfCompletion')?.value
    };

    this.educations.insert(0, this.createEducationFormGroup(mainEducation));
  }

  // Clear main education form
  private clearMainEducationForm(): void {
    this.employeeForm.patchValue({
      institutionName: '',
      degreeName: '',
      specialization: '',
      yearOfCompletion: 0
    });
  }

  // Create education form group
 private createEducationFormGroup(education?: Qualification): FormGroup {
  return this.fb.group({
    qualificationId: [education?.qualificationId || ''],
    institutionName: [education?.institutionName || '', Validators.required],
    degreeName: [education?.degreeName || '', Validators.required],
    specialization: [education?.specialization || ''],
    yearOfCompletion: [education?.yearOfCompletion || null, [Validators.required, Validators.min(1900), Validators.max(new Date().getFullYear())]]
  });
}

  // Remove education entry
  removeEducation(index: number): void {
    this.educations.removeAt(index);
  }
  // =============================================
  // DATA LOADING METHODS
  // =============================================

  /**
   * Initial data loading sequence
   */
  private loadInitialData(): void {
    this.isLoading = true;

    Promise.all([
      this.loadOrganizations(),
      this.loadBranches(),
      this.loadGrades(),
      this.loadShifts()
    ])
      .then(() => {
        if (this.branches.length > 0) {
          this.selectedBranchId = this.branches[0].branchId;
        }
        return this.loadDepartments(this.selectedBranchId);
      })
      .then(() => {
        this.loadEmployees();
        this.loadPositions();
      })
      .catch(() => {
        this.isLoading = false;
      });
  }
  private loadOrganizations(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get<any[]>(this.orgApiUrl, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            console.error('Error loading organizations:', error);
            reject(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: (orgs) => {
            this.organizations = orgs;
            if (orgs.length > 0) {
              this.selectedOrgId = orgs[0].orgId; // Default to first organization
            }
            resolve();
          },
          error: (error) => {
            console.error('Error loading organizations:', error);
            reject(error);
          }
        });
    });
  }
  private loadShifts(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get<Shift[]>(this.shiftApiUrl, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            console.error('Error loading shifts:', error);
            this.errorMessage = 'Failed to load shifts. Please try again later.';
            reject(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: (shifts) => {
            this.shifts = shifts;
            resolve();
          },
          error: (error) => {
            reject(error);
          }
        });
    });
  }
  /**
   * Load branches data
   */
  // private loadBranches(): Promise<void> {
  //   return new Promise((resolve, reject) => {
  //     // Immediately set "All Branches" as default
  //     this.branches = [{
  //       branchId: '',
  //       branchName: 'All Branches',
  //       branchCode: '',
  //       dzongkhag: '',
  //       thromde: '',
  //       operationalStatus: true,
  //       organizationName: ''
  //     }];
  //     this.selectedBranchId = '';

  //     this.http.get<Branch[]>(this.branchApiUrl, this.httpOptions)
  //       .pipe(
  //         catchError(() => {
  //           resolve(); // Still resolve to continue flow
  //           return of([]);
  //         })
  //       )
  //       .subscribe({
  //         next: (branches) => {
  //           // Add loaded branches after the initial "All Branches"
  //           this.branches = [...this.branches, ...branches];

  //           // Build location map
  //           this.locationMap = {};
  //           branches.forEach(branch => {
  //             this.locationMap[branch.branchId] = branch.branchName;
  //           });

  //           resolve();
  //         },
  //         error: (error) => {
  //           reject(error);
  //         }
  //       });
  //   });
  // }

  private loadBranches(): Promise<void> {
    return new Promise((resolve, reject) => {
      // Immediately set "All Branches" as default
      this.branches = [{
        branchId: '',
        branchName: 'All Branches',
        branchCode: '',
        dzongkhag: '',
        thromde: '',
        operationalStatus: true,
        organizationName: ''
      }];
      this.selectedBranchId = '';

      this.http.get<Branch[]>(this.branchApiUrl, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            console.error('Error loading branches:', error);
            resolve(); // Still resolve to continue flow
            return of([]);
          })
        )
        .subscribe({
          next: (branches) => {
            // Add loaded branches after the initial "All Branches"
            this.branches = [...this.branches, ...branches];

            // Build location map and locations array
            this.locationMap = {};
            this.locations = []; // Clear existing locations

            branches.forEach(branch => {
              this.locationMap[branch.branchId] = branch.branchName;
              this.locations.push(branch.branchName); // Add branch name to locations array
            });

            resolve();
          },
          error: (error) => {
            console.error('Error loading branches:', error);
            reject(error);
          }
        });
    });
  }
  // Branch change handler for form add/edit model
  onBranchChangeInForm(): void {
    const selectedBranchName = this.employeeForm.get('location')?.value;
    const selectedBranch = this.branches.find(b => b.branchName === selectedBranchName);

    if (selectedBranch) {
      this.loadDepartments(selectedBranch.branchId).then(() => {
        // Reset department selection when branch changes
        this.employeeForm.get('department')?.setValue('');
      });
    }
  }

  // nationality change handler for the form add
  onNationalityChange(): void {
    const isBhutanese = this.employeeForm.get('nationality')?.value === 'Bhutanese';

    // Get form controls
    const addressLine1 = this.employeeForm.get('addressLine1');
    const addressLine2 = this.employeeForm.get('addressLine2');
    const thromde = this.employeeForm.get('thromde');
    const dzongkhag = this.employeeForm.get('dzongkhag');

    // Clear and reset fields based on nationality
    if (isBhutanese) {
      // Clear Non-Bhutanese fields only if they exist
      if (addressLine2?.value) {
        this.employeeForm.patchValue({ addressLine2: '' });
      }

      // Set validators for Bhutanese fields
      addressLine1?.clearValidators();
      addressLine2?.clearValidators();
      thromde?.clearValidators();
      dzongkhag?.clearValidators();
    } else {
      // Clear Bhutanese fields only if they exist
      if (thromde?.value || dzongkhag?.value) {
        this.employeeForm.patchValue({
          thromde: '',
          dzongkhag: ''
        });
      }

      // Set validators for Non-Bhutanese fields
      addressLine1?.clearValidators();
      addressLine2?.clearValidators();
      thromde?.clearValidators();
      dzongkhag?.clearValidators();
    }

    // Update validity for all affected controls
    addressLine1?.updateValueAndValidity();
    addressLine2?.updateValueAndValidity();
    thromde?.updateValueAndValidity();
    dzongkhag?.updateValueAndValidity();
  }
  /**
   * Load departments for a specific branch
   */
  private loadDepartments(branchId?: string): Promise<void> {
    return new Promise((resolve, reject) => {
      let url = this.deptApiUrl;
      if (branchId) {
        url = `${this.deptApiUrl}/branch/${branchId}`;
      }

      this.http.get<{ success: boolean, message: string, data: Department[] }>(url, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            this.errorMessage = 'Failed to load departments. Please try again later.';
            reject(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: (response) => {
            if (response.success && response.data) {
              this.formDepartments = response.data;
              this.filteredDepartments = [...response.data];
              this.departmentMap = {};

              this.tabDepartments = [
                'All Employee',
                ...response.data.map(dept => dept.dept_name)
              ];

              response.data.forEach(dept => {
                this.departmentMap[dept.dept_id] = dept.dept_name;
              });
              resolve();
            } else {
              reject(new Error('Invalid department data'));
            }
          },
          error: (error) => {
            reject(error);
          }
        });
    });
  }
  // Add these to your EmployeeDetailComponent class

  hasActiveFilters(): boolean {
    return !!this.selectedBranchId ||
      this.activeTab !== 'All Employee' ||
      !!this.searchQuery;
  }
  /**
     * clear all filters
     */
  clearAllFilters(): void {
    // Reset branch filter
    this.selectedBranchId = '';

    // Reset department filter
    this.activeTab = 'All Employee';

    // Reset search
    this.searchQuery = '';

    // Apply the cleared filters
    this.applyFilters();
  }
  /**
   * Load job positions
   */
  private loadPositions(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get<Position[]>(this.positionApiUrl, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            this.errorMessage = 'Failed to load positions. Please try again later.';
            reject(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: (positions) => {
            this.positions = positions;
            this.filteredPositions = [...positions];
            this.positionMap = {};

            positions.forEach(pos => {
              this.positionMap[pos.positionId] = pos.positionName;
            });
            resolve();
          },
          error: (error) => {
            this.errorMessage = 'Failed to load positions. Please try again later.';
            reject(error);
          }
        });
    });
  }

  /**
   * Load job grades
   */
  private loadGrades(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get<Grade[]>(this.gradeApiUrl, this.httpOptions)
        .pipe(
          catchError((error: HttpErrorResponse) => {
            this.errorMessage = 'Failed to load grades. Please try again later.';
            reject(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: (grades) => {
            this.grades = grades;
            resolve();
          },
          error: (error) => {
            reject(error);
          }
        });
    });
  }

  /**
   * Load employee data
   */
  private loadEmployees(): void {
    this.isLoading = true;
    this.errorMessage = '';

    const currentUser = this.authService.currentUserValue;
    const isAdmin = currentUser?.roleCode === 'ROLE_ADMIN';
    const isEmployee = currentUser?.roleCode === 'ROLE_EMPLOYEE';
    const isManager = currentUser?.roleCode === 'ROLE_MANAGER';
    const isDeptHead = currentUser?.roleCode === 'ROLE_MANAGER' && currentUser?.isDeptHead;
    const userDeptId = currentUser?.deptID;

    let apiUrl = this.apiUrl;

    if (isEmployee && currentUser?.empId) {
      apiUrl = `${this.apiUrl}/${currentUser.empId}`;
    }
    else if (isDeptHead && userDeptId) {
      // For department heads, we'll load all employees and filter client-side
      apiUrl = this.apiUrl;
    }

    this.http.get<ApiEmployeeResponse[] | ApiEmployeeResponse>(apiUrl, this.httpOptions)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          this.isLoading = false;
          this.handleError(error);
          return throwError(() => error);
        }),
        map(response => {
          // If department head, filter employees by their department
          if (isDeptHead && userDeptId) {
            if (Array.isArray(response)) {
              return response.filter(emp => emp.employee.deptId === userDeptId);
            }
            // Handle single response case if needed
            return response.employee.deptId === userDeptId ? [response] : [];
          }
          return response;
        })
      )
      .subscribe({
        next: (response) => {
          if (isEmployee || (isDeptHead && !Array.isArray(response))) {
            // Handle single employee response
            const singleResponse = response as ApiEmployeeResponse;
            this.employees = [this.mapApiEmployee(singleResponse)];
          } else {
            // Handle array response
            const arrayResponse = response as ApiEmployeeResponse[];
            this.employees = arrayResponse.map(emp => this.mapApiEmployee(emp));
          }

          this.applyFilters();
          this.isLoading = false;
        },
        error: () => this.isLoading = false
      });
  }
  private handleError(error: HttpErrorResponse): void {
    if (error.status === 404) {
      this.errorMessage = 'API endpoint not found. Check if the server is running.';
    } else if (error.status === 0) {
      this.errorMessage = 'Failed to connect to server. Check your network.';
    } else if (error.status === 403) {
      this.errorMessage = 'You do not have permission to access this resource.';
    } else {
      this.errorMessage = 'An unexpected error occurred.';
    }
  }
  // user permission
  canAddEmployee(): boolean {
    return this.authService.hasPermission('EMP_CREATE') ||
      this.authService.currentUserValue?.roleCode === 'ROLE_ADMIN';
  }

  canEditEmployee(): boolean {
    return this.authService.hasPermission('EMP_EDIT') ||
      this.authService.currentUserValue?.roleCode === 'ROLE_ADMIN';
  }

  canDeleteEmployee(): boolean {
    return this.authService.hasPermission('EMP_DELETE') ||
      this.authService.currentUserValue?.roleCode === 'ROLE_ADMIN';
  }

  canExport(): boolean {
    return this.authService.hasPermission('EMP_EXPORT') ||
      this.authService.currentUserValue?.roleCode === 'ROLE_ADMIN';
  }
  /**
 * Map API response to local employee structure
 */
  private mapApiEmployee(apiEmployee: ApiEmployeeResponse): Employee {
    const primaryContact = apiEmployee.contacts?.slice(-1)[0] || {
      email: '', phonePrimary: '', isEmergencyContact: false
    };
    const primaryAddress = apiEmployee.addresses?.slice(-1)[0] || {
      addressType: 'Permanent', addressLine1: '', addressLine2: '',
      thromde: '', dzongkhag: '', country: 'Bhutan', isCurrent: true
    };
    const primaryQualification = apiEmployee.qualifications?.slice(-1)[0] || {
      institutionName: '', degreeName: '', specialization: '', yearOfCompletion: 0
    };
    const primaryBankDetail = apiEmployee.bankDetails?.slice(-1)[0] || {
      bankName: '', branchName: '', accountNumber: '', accountType: ''
    };

    return {
      empId: apiEmployee.employee.empId,
      empCode: apiEmployee.employee.empCode,
      firstName: apiEmployee.employee.firstName,
      middleName: apiEmployee.employee.middleName || undefined,
      lastName: apiEmployee.employee.lastName,
      dateOfBirth: apiEmployee.employee.dateOfBirth,
      gender: apiEmployee.employee.gender,
      maritalStatus: apiEmployee.employee.maritalStatus || 'Single',
      nationality: apiEmployee.employee.nationality,
      cidNumber: apiEmployee.employee.cidNumber,
      hireDate: apiEmployee.employee.hireDate,
      employmentStatus: apiEmployee.employee.employmentStatus,
      employmentType: apiEmployee.employee.employmentType,
      email: primaryContact.email,
      deptId: apiEmployee.employee.deptId,
      department: this.getDepartmentName(apiEmployee.employee.deptId),
      positionId: apiEmployee.employee.positionId,
      positionName: this.getPositionName(apiEmployee.employee.positionId),
      location: this.getLocationName(apiEmployee.employee.branchId),
      orgId: apiEmployee.employee.orgId,
      branchId: apiEmployee.employee.branchId,
      shiftId: apiEmployee.employee.shiftId,
      gradeId: apiEmployee.employee.gradeId,
      basicSalary: apiEmployee.employee.basicSalary,
      maxSalary: apiEmployee.employee.maxSalary,
      contacts: [primaryContact],
      addresses: [primaryAddress],
      qualifications: [primaryQualification],
      bankDetails: [primaryBankDetail]
    };
  }

  // =============================================
  // UI INTERACTION METHODS
  // =============================================

  /**
   * Modal tab management
   */
  selectModalTab(tab: string): void {
    this.modalActiveTab = tab;
  }

  isModalTabActive(tab: string): boolean {
    return this.modalActiveTab === tab;
  }

  /**
   * View tab management
   */
  setActiveTab(tabId: string): void {
    this.activeViewTab = tabId;
  }

  isTabActive(tabId: string): boolean {
    return this.activeViewTab === tabId;
  }

  /**
   * Open/close modal methods
   */
  openModal(): void {
    this.showModal = true;
    this.isEditMode = false;
    this.editedIndex = -1;
    this.selectModalTab('basic');

    this.loadPositions().then(() => {
      this.employeeForm.reset({
        department: '',
        position: '',
        location: '',
        gender: '',
        maritalStatus: '',
        employmentStatus: '',
        employmentType: '',
        accountType: '',
        addressType: '',
        grade: '',
        organization: this.selectedOrgId,
        nationality: 'Bhutanese'
      });
      this.onNationalityChange();
      if (this.employeeForm.get('department')?.value) {
        this.employeeForm.get('position')?.enable();
      }
    }).catch(error => {
      console.error('Failed to load positions:', error);
      this.employeeForm.reset({
        department: this.formDepartments.length > 0 ? this.formDepartments[0].dept_id : '',
        position: null,
        location: this.locations[0],
        maritalStatus: 'Single',
        employmentStatus: 'Active',
        employmentType: 'Regular',
        addressType: 'Permanent'
      });
    });
  }

  closeModal(): void {
    this.showModal = false;
    this.employeeForm.reset();
    this.errorMessage = '';
  }

  closeViewModal(): void {
    this.showViewModal = false;
    this.selectedEmployee = null;
  }

  // =============================================
  // FORM HANDLING METHODS
  // =============================================

  /**
   * Handle branch selection change
   */
  onBranchChange(): void {
    this.currentPage = 1;
    this.loadDepartments(this.selectedBranchId).then(() => {
      this.applyFilters();
    });
  }
  onOrganizationChange(): void {
    const orgId = this.employeeForm.get('organization')?.value;
    if (orgId) {
      this.selectedOrgId = orgId;
      // You might want to reload branches when organization changes
      this.loadBranches();
    }
  }
  /**
   * Handle department selection change
   */
  onDepartmentChange(): void {
    const positionControl = this.employeeForm.get('position');
    positionControl?.enable();

    if (this.positions.length > 0 && !positionControl?.value) {
      positionControl?.setValue(this.positions[0].positionId);
    }
  }

  /**
   * Handle position selection change
   */
  onPositionChange(): void {
    const selectedPositionId = this.employeeForm.get('position')?.value;
    console.log('Position changed to:', selectedPositionId);
  }

  /**
   * Handle grade selection change
   */
  onGradeChange(event: Event): void {
    const gradeId = (event.target as HTMLSelectElement).value;
    if (gradeId) {
      this.selectedGrade = this.grades.find(g => g.gradeId === gradeId) || null;
      if (this.selectedGrade) {
        this.fetchSalaryStructure(gradeId);
      }
    } else {
      this.selectedGrade = null;
      this.salaryStructure = null;
      this.employeeForm.patchValue({
        basicSalary: '',
        maxSalary: ''
      });
    }
  }

  /**
   * Fetch salary structure for selected grade
   */
  private fetchSalaryStructure(gradeId: string): void {
    this.http.get<SalaryStructure>(`${this.gradeApiUrl}/${gradeId}/with-salary-structure`, this.httpOptions)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          console.error('Failed to load salary structure:', error);
          this.errorMessage = 'Failed to load salary details.';
          return throwError(() => error);
        })
      )
      .subscribe({
        next: (structure) => {
          this.salaryStructure = structure;
          this.employeeForm.patchValue({
            basicSalary: structure.minSalary,
            maxSalary: structure.maxSalary
          });
        },
        error: (error) => {
          console.error('Error loading salary structure:', error);
        }
      });
  }

  /**
   * Set form values for editing an employee
   */
  private setFormValues(emp: Employee, deptId: string): void {
    const primaryContact = emp.contacts?.[0] || {
      email: '',
      phonePrimary: '',
      isEmergencyContact: false
    };

    const primaryBank = emp.bankDetails?.[0] || {
      bankName: '',
      branchName: '',
      accountNumber: '',
      accountType: ''
    };

    const highestQualification = emp.qualifications?.[0] || {
      institutionName: '',
      degreeName: '',
      specialization: '',
      yearOfCompletion: 0
    };

    const currentAddress: Address = emp.addresses?.find(a => a.isCurrent) || emp.addresses?.[0] || {
      addressType: 'Permanent',
      addressLine1: '',
      addressLine2: '',
      thromde: '',
      dzongkhag: '',
      country: 'Bhutan',
      isCurrent: false
    };

    this.employeeForm.patchValue({
      empCode: emp.empCode,
      firstName: emp.firstName,
      middleName: emp.middleName,
      lastName: emp.lastName,
      dateOfBirth: this.formatDateForInput(emp.dateOfBirth),
      gender: emp.gender,
      maritalStatus: emp.maritalStatus,
      nationality: emp.nationality || 'Bhutanese',
      cidNumber: emp.cidNumber,
      organization: emp.orgId || this.selectedOrgId,
      hireDate: this.formatDateForInput(emp.hireDate),
      employmentStatus: emp.employmentStatus,
      employmentType: emp.employmentType || '',
      email: primaryContact.email,
      department: deptId || '',
      position: emp.positionId || null,
      location: emp.location,
      phonePrimary: primaryContact.phonePrimary,
      shift: emp.shiftId || '',
      grade: emp.gradeId || '',
      basicSalary: emp.basicSalary || '',
      maxSalary: emp.maxSalary || '',
      bankName: primaryBank.bankName,
      branchName: primaryBank.branchName,
      accountNumber: primaryBank.accountNumber,
      accountType: primaryBank.accountType,
      institutionName: highestQualification.institutionName,
      degreeName: highestQualification.degreeName,
      specialization: highestQualification.specialization,
      yearOfCompletion: highestQualification.yearOfCompletion || 0,
      addressType: currentAddress.addressType,
      addressLine1: currentAddress.addressLine1,
      addressLine2: currentAddress.addressLine2,
      thromde: currentAddress.thromde,
      dzongkhag: currentAddress.dzongkhag

    });
    this.onNationalityChange();
    if (emp.gradeId) {
      this.fetchSalaryStructure(emp.gradeId);
    }
    while (this.educations.length) {
      this.educations.removeAt(0);
    }
    if (emp.qualifications && emp.qualifications.length > 0) {
      // Set first qualification in main form
      const [firstQualification, ...additionalQualifications] = emp.qualifications;

      this.employeeForm.patchValue({
        institutionName: firstQualification.institutionName,
        degreeName: firstQualification.degreeName,
        specialization: firstQualification.specialization,
        yearOfCompletion: firstQualification.yearOfCompletion
      });

      // Add remaining qualifications to educations array
      additionalQualifications.forEach(qual => {
        this.educations.push(this.createEducationFormGroup(qual));
      });
    }
  }

  // =============================================
  // EMPLOYEE CRUD OPERATIONS
  // =============================================


private createUserAccount(empId: string): Observable<any> {
  if (!empId) {
    const errorMsg = 'Missing employee ID for user account creation';
    console.error('User account creation failed:', errorMsg);
    return throwError(() => new Error(errorMsg));
  }

  console.log('Creating user account for employee ID:', empId);

  // No payload needed - backend will fetch details from database
  return this.http.post(
    `${environment.apiUrl}/api/auth/user-accounts/create/${empId}`, 
    null, // No payload required
    { 
      headers: this.httpOptions.headers,
      observe: 'response',
      responseType: 'text'
    }
  ).pipe(
    tap(response => {
      console.log('User account creation API response:', response);
      console.log('Response status:', response.status);
      console.log('Response body:', response.body);
    }),
    
    // Map the response to a standardized format
    map(response => {
      // Check if status is successful (200-299)
      if (response.status >= 200 && response.status < 300) {
        return {
          success: true,
          status: response.status,
          message: response.body || 'User account created successfully',
          data: response.body
        };
      }
      
      // If status is not in 200-299 range, throw error
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }),
    
    // Handle specific error cases
    catchError(error => {
      console.error('User account creation error:', {
        error: error,
        status: error.status,
        statusText: error.statusText,
        url: error.url,
        headers: error.headers,
        errorResponse: error.error
      });
      
      // Check if this is a 200 status that was incorrectly treated as error
      if (error.status === 200 && error.statusText === 'OK') {
        return of({
          success: true,
          status: error.status,
          message: 'User account created successfully (recovered from parsing error)',
          recoveredFromError: true
        });
      }
      
      // Handle specific HTTP error codes
      let userFriendlyMessage = 'Failed to create user account.';
      
      switch (error.status) {
        case 400:
          userFriendlyMessage = 'Bad request. Please check if the employee data is valid.';
          break;
        case 409:
          userFriendlyMessage = 'User account already exists for this employee.';
          break;
        case 404:
          userFriendlyMessage = 'User creation endpoint not found. Please contact administrator.';
          break;
        case 500:
          userFriendlyMessage = 'Server error occurred while creating user account.';
          break;
        case 0:
          userFriendlyMessage = 'Network error: Could not connect to server.';
          break;
      }
      
      // Return a standardized error response
      return throwError(() => ({
        success: false,
        status: error.status,
        message: userFriendlyMessage,
        technicalMessage: error.message,
        error: error.error
      }));
    })
  );
}


private openUserCreationModal(empId: string, empCode: string, details: any): void {
  console.log('Opening user creation modal with details:', { empId, empCode, details });
  
  this.newEmployeeId = empId;
  this.newEmployeeCode = empCode;
  this.newEmployeeDetails = details;
  
  // Use setTimeout to ensure the modal shows after the current execution cycle
  setTimeout(() => {
    this.showUserCreationModal = true;
    console.log('Modal should be visible now. showUserCreationModal =', this.showUserCreationModal);
  }, 100);
}

closeUserCreationModal(): void {
  console.log('Closing user creation modal');
  this.showUserCreationModal = false;
  this.isCreatingUser = false;
  this.newEmployeeId = null;
  this.newEmployeeCode = '';
  this.newEmployeeDetails = null;
}

confirmUserCreation(): void {
  if (!this.newEmployeeId) {
    console.error('No employee ID found for user creation');
    alert('No employee ID found for user creation.');
    return;
  }
  
  console.log('Starting user account creation for employee ID:', this.newEmployeeId);
  this.isCreatingUser = true;
  
  this.createUserAccount(this.newEmployeeId).subscribe({
    next: (response: any) => {
      console.log('User account creation response:', response);
      this.isCreatingUser = false;
      this.closeUserCreationModal();
      
      if (response.success) {
        alert(`User account created successfully! ${response.message || ''}`);
      } else {
        alert(`User account creation completed with status: ${response.message || 'Unknown status'}`);
      }
    },
    error: (error) => {
      console.error('User account creation failed:', error);
      this.isCreatingUser = false;
      
      const errorMessage = error.message || 'Failed to create user account.';
      alert(`${errorMessage} You can create the user account manually later.`);
      
      // Don't close modal on error - let user decide
    }
  });
}
declineUserCreation(): void {
  console.log('User declined user account creation');
  this.closeUserCreationModal();
  alert('Employee saved successfully. You can create a user account later from the user management section.');
}
  /**
   * Save employee (create or update)
   */
/**
 * Save employee (create or update)
 */
/**
 * Save employee (create or update)
 */
saveEmployee(): void {
  if (this.employeeForm.invalid) {
    this.errorMessage = 'Please fill all required fields correctly.';
    this.employeeForm.markAllAsTouched();
    return;
  }

  // Save main education to array if it has values
  if (this.hasMainEducationValues()) {
    this.saveMainEducationToArray();
  }

  this.isSaving = true;
  this.errorMessage = '';

  const formValue = this.employeeForm.getRawValue();
  const empId = this.isEditMode ? this.selectedEmployee?.empId : undefined;
  const isBhutanese = formValue.nationality === 'Bhutanese';

  try {
    const branchId = this.getBranchId(formValue.location);
    if (!branchId) {
      throw new Error('Invalid location selected');
    }

    // Get the most recent existing IDs
    const existingContact = this.selectedEmployee?.contacts?.slice(-1)[0];
    const existingAddress = this.selectedEmployee?.addresses?.slice(-1)[0];
    const existingQualification = this.selectedEmployee?.qualifications?.slice(-1)[0];
    const existingBankDetail = this.selectedEmployee?.bankDetails?.slice(-1)[0];

    // Prepare address payload based on nationality
    const addressPayload: any = {
      addressId: existingAddress?.addressId || undefined,
      addressType: formValue.addressType || 'Permanent',
      addressLine1: formValue.addressLine1,
      isCurrent: true
    };

    if (isBhutanese) {
      addressPayload.addressLine2 = '';
      addressPayload.thromde = formValue.thromde;
      addressPayload.dzongkhag = formValue.dzongkhag;
      addressPayload.country = 'Bhutan';
    } else {
      addressPayload.addressLine2 = formValue.addressLine2;
      addressPayload.thromde = '';
      addressPayload.dzongkhag = '';
      addressPayload.country = 'Non-Bhutanese';
    }

    const shiftId = formValue.shift;
    if (!this.shifts.some(s => s.shiftId === shiftId)) {
      this.errorMessage = 'Invalid shift selected';
      this.isSaving = false;
      return;
    }

    // Create contact payload with explicit contact_type
    const contactPayload = {
      contactId: existingContact?.contactId || undefined,
  contactType: 'Email',      // Camel case version  
  email: formValue.email,
  phonePrimary: formValue.phonePrimary,
  phoneSecondary: '',
  isEmergencyContact: false,
  relationship: 'Self',
  priorityLevel: 1
    };

    console.log('Contact payload:', contactPayload);

    const payload = {
      employee: {
        empId: empId,
        empCode: formValue.empCode,
        firstName: formValue.firstName,
        middleName: formValue.middleName || null,
        lastName: formValue.lastName,
        positionId: formValue.position,
        deptId: formValue.department,
        dateOfBirth: this.formatDateForAPI(formValue.dateOfBirth),
        gender: formValue.gender,
        maritalStatus: formValue.maritalStatus,
        nationality: formValue.nationality,
        cidNumber: formValue.cidNumber,
        hireDate: this.formatDateForAPI(formValue.hireDate),
        employmentStatus: formValue.employmentStatus,
        employmentType: formValue.employmentType,
        branchId: branchId,
        orgId: formValue.organization,
        shiftId: formValue.shift,
        gradeId: formValue.grade,
        basicSalary: formValue.basicSalary,
        maxSalary: formValue.maxSalary
      },
      contacts: [contactPayload], // Use the properly constructed contact payload
      addresses: [addressPayload],
      qualifications: this.educations.controls.map(control => ({
        qualificationId: control.value.qualificationId || undefined,
        institutionName: control.value.institutionName,
        degreeName: control.value.degreeName,
        specialization: control.value.specialization,
        yearOfCompletion: control.value.yearOfCompletion
      })),
      bankDetails: [{
        bankDetailId: existingBankDetail?.bankDetailId || undefined,
        bankName: formValue.bankName,
        branchName: formValue.branchName,
        accountNumber: formValue.accountNumber,
        accountType: formValue.accountType
      }],
      updateOperation: this.isEditMode
    };

    console.log('Full payload being sent:', JSON.stringify(payload, null, 2));

    const request$ = this.isEditMode && empId
      ? this.http.put(`${this.apiUrl}/${empId}`, payload, this.httpOptions)
      : this.http.post(this.apiUrl, payload, this.httpOptions);

    request$.pipe(
      catchError(err => {
        console.error('Error saving employee:', {
          status: err.status,
          message: err.message,
          error: err.error
        });
        this.errorMessage = this.extractErrorMessage(err);
        this.isSaving = false;
        return throwError(() => err);
      })
    ).subscribe({
      next: (response: ApiEmployeeResponse | any) => {
        this.isSaving = false;
        
        const generatedCode = (response as ApiEmployeeResponse)?.employee?.empCode ||
          response?.empCode ||
          'N/A';
        
        const savedEmpId = (response as ApiEmployeeResponse)?.employee?.empId ||
          response?.empId;
          
        console.log('Employee saved successfully with code:', generatedCode);
        console.log('Employee ID:', savedEmpId);
        console.log('Full response:', response);
        
        // Close the main modal first
        this.closeModal();
        
        // Handle the update response (refresh employee list)
        this.handleUpdateResponse(response, empId);
        
        // Show user creation modal only for NEW employees (not edits)
        if (!this.isEditMode && savedEmpId) {
          const employeeDetails = {
            firstName: formValue.firstName,
            lastName: formValue.lastName,
            email: formValue.email,
            department: this.getDepartmentName(formValue.department),
            position: this.getPositionName(formValue.position)
          };
          
          this.openUserCreationModal(savedEmpId, generatedCode, employeeDetails);
        } else if (this.isEditMode) {
          alert(`Employee ${generatedCode} updated successfully!`);
        }
      },
      error: (err) => {
        console.error('Save failed:', err);
        this.isSaving = false;
      }
    });
  } catch (error) {
    this.errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    this.isSaving = false;
    console.error('Exception in saveEmployee:', error);
  }
}
  private getFormValidationErrors(): any {
    const errors = {};
    Object.keys(this.employeeForm.controls).forEach(key => {
      const control = this.employeeForm.get(key);
      if (control?.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }
  /**
   * Handle response from save operation
   */
  private handleUpdateResponse(response: any, empId?: string): void {
    if (!empId) {
      this.loadEmployees();
      return;
    }

    const updatedEmployee = this.mapApiEmployee(response as ApiEmployeeResponse);

    const index = this.employees.findIndex(e => e.empId === empId);
    if (index !== -1) {
      this.employees[index] = updatedEmployee;
    }

    const filteredIndex = this.filteredEmployees.findIndex(e => e.empId === empId);
    if (filteredIndex !== -1) {
      this.filteredEmployees[filteredIndex] = updatedEmployee;
    }

    this.applyFilters();
  }

  /**
   * Edit an employee
   */
  editEmployee(identifier: number | string): void {
    let employeeToEdit: Employee | undefined;

    if (typeof identifier === 'number') {
      employeeToEdit = this.filteredEmployees[identifier];
    } else {
      employeeToEdit = this.employees.find(emp => emp.empCode === identifier);
    }

    if (!employeeToEdit) return;

    this.isEditMode = true;
    this.selectedEmployee = { ...employeeToEdit };

    const dept = this.formDepartments.find(d =>
      d.dept_name === this.selectedEmployee?.department
    );

    this.loadPositions().then(() => {
      console.log('Available positions:', this.positions);
      console.log('Employee position ID:', employeeToEdit?.positionId);

      this.setFormValues(this.selectedEmployee, dept?.dept_id || '');
      this.showModal = true;
    }).catch(error => {
      console.error('Failed to load positions:', error);
      this.setFormValues(this.selectedEmployee, dept?.dept_id || '');
      this.showModal = true;
    });
  }

  /**
   * Delete an employee
   */
  deleteEmployee(index: number): void {
    const emp = this.filteredEmployees[index];
    if (!emp || !emp.empId) return;

    if (confirm(`Are you sure you want to delete employee ${emp.empCode}?`)) {
      this.http.delete(`${this.apiUrl}/${emp.empId}`, this.httpOptions)
        .pipe(
          catchError(error => {
            this.errorMessage = this.extractErrorMessage(error);
            return throwError(() => error);
          })
        )
        .subscribe({
          next: () => {
            this.employees = this.employees.filter(e => e.empId !== emp.empId);
            this.applyFilters();
          },
          error: (error) => {
            console.error('Delete error:', error);
          }
        });
    }
  }

  /**
   * View employee details
   */
  viewEmployee(empId: string) {
    this.router.navigate(['view', empId], { relativeTo: this.route });
  }

  // =============================================
  // FILTERING & PAGINATION
  // =============================================

  /**
   * Apply filters to employee list
   */
  applyFilters(): void {
    const search = this.searchQuery.toLowerCase().trim();
    const currentUser = this.authService.currentUserValue;

    // If user is department head, force filter by their department
    const isDeptHead = currentUser?.roleCode === 'ROLE_MANAGER' && currentUser?.isDeptHead;
    const forceDeptFilter = isDeptHead ? currentUser?.deptID : null;

    const filtered = this.employees.filter(emp => {
      // Department filter - enforce for department heads
      const matchesDept = forceDeptFilter
        ? emp.deptId === forceDeptFilter
        : this.activeTab === 'All Employee' || emp.department === this.activeTab;

      // Branch filter
      const matchesBranch = this.selectedBranchId === '' ||
        emp.branchId === this.selectedBranchId;

      // Early exit if either filter fails
      if (!matchesDept || !matchesBranch) return false;

      // Only perform search if needed
      if (!search) return true;

      return (
        (emp.empCode?.toLowerCase().includes(search)) ||
        (emp.firstName?.toLowerCase().includes(search)) ||
        (emp.lastName?.toLowerCase().includes(search)) ||
        (emp.email?.toLowerCase().includes(search)) ||
        (emp.positionName?.toLowerCase().includes(search))
      );
    });

    this.totalItems = filtered.length;
    this.currentPage = Math.min(this.currentPage, this.totalPages());

    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    this.filteredEmployees = filtered.slice(startIndex, startIndex + this.itemsPerPage);
  }

  /**
   * Select department tab
   */
  selectTab(dept: string): void {
    this.activeTab = dept;
    this.currentPage = 1;
    this.applyFilters();
  }

  /**
   * Pagination methods
   */
  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages()) return;
    this.currentPage = page;
    this.applyFilters();
  }

  totalPages(): number {
    return Math.ceil(this.totalItems / this.itemsPerPage);
  }

  getPages(): number[] {
    const pages = [];
    const total = this.totalPages();
    const maxVisiblePages = 5;

    if (total <= maxVisiblePages) {
      for (let i = 1; i <= total; i++) {
        pages.push(i);
      }
    } else {
      const half = Math.floor(maxVisiblePages / 2);
      let start = Math.max(1, this.currentPage - half);
      let end = Math.min(total, start + maxVisiblePages - 1);

      if (end - start + 1 < maxVisiblePages) {
        start = Math.max(1, end - maxVisiblePages + 1);
      }

      if (start > 1) {
        pages.push(1);
        if (start > 2) {
          pages.push(-1);
        }
      }

      for (let i = start; i <= end; i++) {
        if (i > 0 && i <= total) {
          pages.push(i);
        }
      }

      if (end < total) {
        if (end < total - 1) {
          pages.push(-1);
        }
        pages.push(total);
      }
    }

    return pages;
  }

  onItemsPerPageChange(): void {
    this.currentPage = 1;
    this.applyFilters();
  }

  // =============================================
  // UTILITY METHODS
  // =============================================

  /**
   * Get department name from ID
   */
  private getDepartmentName(deptId: string): string {
    const dept = this.formDepartments.find(d => d.dept_id === deptId);
    return dept?.dept_name || 'Not specified';
  }

  /**
   * Get position name from ID
   */
  private getPositionName(positionId: string): string {
    const position = this.positions.find(p => p.positionId === positionId);
    return position?.positionName || 'Not specified';
  }

  /**
   * Get location name from branch ID
   */
  private getLocationName(branchId: string): string {
    const branch = this.branches.find(b => b.branchId === branchId);
    return branch?.branchName || 'Not specified';
  }

  /**
   * Get branch ID from location name
   */
  private getBranchId(locationName: string): string {
    if (!locationName) {
      console.error('Location name is empty');
      return '';
    }

    const branch = this.branches.find(b =>
      b.branchName.trim().toLowerCase() === locationName.trim().toLowerCase()
    );

    if (!branch) {
      console.error('Branch not found for location:', locationName);
      console.log('Available branches:', this.branches.map(b => b.branchName));
      throw new Error(`Branch not found for location: ${locationName}`);
    }

    return branch.branchId;
  }

  /**
   * Format date for display in input fields
   */
  private formatDateForInput(dateString: string): string {
    if (!dateString) return '';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return '';
      return date.toISOString().split('T')[0];
    } catch (e) {
      console.error('Date formatting error:', e);
      return '';
    }
  }

  /**
   * Format date for API requests
   */
  private formatDateForAPI(date: Date | string): string {
    try {
      const d = date ? new Date(date) : new Date();
      if (isNaN(d.getTime())) throw new Error('Invalid date');
      return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
    } catch (e) {
      console.error('Date formatting error:', e);
      return ''; // or handle differently
    }
  }

  /**
   * Extract error message from HTTP response
   */
  private extractErrorMessage(error: any): string {
    if (!error) return 'An unknown error occurred';

    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        return 'Network error: Could not connect to server';
      }
      if (error.status === 404) {
        return 'The requested resource was not found';
      }

      try {
        const serverError = error.error;
        if (serverError?.message) {
          return serverError.message;
        }
        if (typeof serverError === 'string') {
          return serverError;
        }
      } catch (e) {
        console.error('Error parsing error response:', e);
      }

      return `Server error: ${error.status} ${error.statusText}`;
    }

    return error.message || 'An unknown error occurred';
  }

  // =============================================
  // EXPORT & UI HELPERS
  // =============================================

  /**
   * Export employee data to CSV
   */
  exportToCSV(): void {
    const headers = [
      'Employee Code', 'First Name', 'Middle Name', 'Last Name', 'Date of Birth', 'Gender',
      'Marital Status', 'Nationality', 'CID Number',
      'Hire Date', 'Employment Status', 'Employment Type', 'Email', 'Department', 'Position', 'Location',
      'Bank Name', 'Branch Name', 'Account Number', 'Account Type',
      'Institution Name', 'Degree Name', 'Specialization', 'Year of Completion',
      'Thromde', 'Dzongkhag', 'Country', 'Phone Number', 'Emergency Contact'
    ];

    const rows = this.filteredEmployees.map(emp => {
      const primaryContact: Contact = emp.contacts?.[0] || {
        contactType: 'Email',
        email: '',
        phonePrimary: '',
        isEmergencyContact: false
      };

      const primaryBank: BankDetail = emp.bankDetails?.[0] || {
        bankName: '',
        branchName: '',
        accountNumber: '',
        accountType: ''
      };

      const highestQualification: Qualification = emp.qualifications?.[0] || {
        institutionName: '',
        degreeName: '',
        specialization: '',
        yearOfCompletion: 0
      };

      const currentAddress: Address = emp.addresses?.find(a => a.isCurrent) || emp.addresses?.[0] || {
        addressType: 'Permanent',
        addressLine1: '',
        addressLine2: '',
        thromde: '',
        dzongkhag: '',
        country: 'Bhutan',
        isCurrent: false
      };

      return [
        emp.empCode ?? '',
        emp.firstName ?? '',
        emp.middleName ?? '',
        emp.lastName ?? '',
        emp.dateOfBirth ? new Date(emp.dateOfBirth).toLocaleDateString() : '',
        emp.gender ?? '',
        emp.maritalStatus ?? '',
        emp.nationality ?? '',
        emp.cidNumber ?? '',
        emp.hireDate ? new Date(emp.hireDate).toLocaleDateString() : '',
        emp.employmentStatus ?? '',
        emp.employmentType ?? '',
        emp.email ?? '',
        emp.department ?? '',
        emp.positionName ?? '',
        emp.location ?? '',
        primaryBank.bankName ?? '',
        primaryBank.branchName ?? '',
        primaryBank.accountNumber ?? '',
        primaryBank.accountType ?? '',
        highestQualification.institutionName ?? '',
        highestQualification.degreeName ?? '',
        highestQualification.specialization ?? '',
        highestQualification.yearOfCompletion ?? '',
        currentAddress.thromde ?? '',
        currentAddress.dzongkhag ?? '',
        currentAddress.country ?? '',
        primaryContact.phonePrimary ?? '',
        primaryContact.isEmergencyContact ? 'Yes' : 'No'
      ];
    });

    let csvContent = headers.join(',') + '\n';
    rows.forEach(row => {
      csvContent += row.map(field => `"${field.toString().replace(/"/g, '""')}"`).join(',') + '\n';
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `employees_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Get CSS class for department badge
   */
  getDeptBadgeClass(department: string): string {
    const classes: Record<string, string> = {
      'E-Centric': 'emp-dept-e-centric',
      'Content Division': 'emp-dept-content-division',
      'CSO': 'emp-dept-cso',
      'HR': 'emp-dept-hr',
      'Marketing': 'emp-dept-marketing',
      'Finance': 'emp-dept-finance',
      'Management and Accounts': 'emp-dept-management-accounts',
      'SMD': 'emp-dept-smd',
      'IT': 'emp-dept-it',
      'Operations': 'emp-dept-operations',
      'TSSD': 'emp-dept-sales',
      'Customer Support': 'emp-dept-customer-support'
    };
    return classes[department] || 'emp-dept-default';
  }

}