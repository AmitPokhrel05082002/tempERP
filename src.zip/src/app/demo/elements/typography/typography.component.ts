// angular import
import { Component } from '@angular/core';

@Component({
  selector: 'app-typography',
  imports: [],
  templateUrl: './typography.component.html',
  styleUrls: ['./typography.component.scss']
})
export default class TypographyComponent {}
